import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './mainpages/home/home.component';
import { MenuComponent } from './mainpages/menu/menu.component';
import { MenupageComponent } from './mainpages/menupage/menupage.component';
import {AboutComponent} from './mainpages/about/about.component';
import { ContactComponent } from './mainpages/contact/contact.component';


const routes: Routes = [  {path:'', pathMatch:'full',redirectTo:'/home'  },
                          {path:'home',component:HomeComponent  },
                          {path:'menu',component:MenuComponent},
                          {path:'menu/:id',component:MenupageComponent},
                          {path:'about',component:AboutComponent},
                          {path:'contact',component:ContactComponent}
                     

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
