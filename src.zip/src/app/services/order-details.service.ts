import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class OrderDetailsService {

  constructor() { }


//foodDetails

foodDetails=[
   {   
      id:1,
      foodName:"Ata noodles",
      foodDetails:"Authentic Indian Noodles with vegetables and masala spices, tasty made from ata",
      foodPrice  :" 290",
      foodImg:"../../assets/img/noodles.jpg"
      


   },
   {   
    id:2,
    foodName:" Burger",
    foodDetails:"Burger is a food, typically considered a sandwich, consisting of  cooked pattie ",
    foodPrice  :" 300",
    foodImg:"../../assets/img/berger1.jpg"
    
  
  
  }
   ,

{   
  id:3,
  foodName:" Rolls",
  foodDetails:"roll, a tongue tickling and spicy masala of grated  paneer wrapped in chapati  ",
  foodPrice  :" 300",
  foodImg:"../../assets/img/rolls.jpg"
  


},

{   
  id:4,
  foodName:"Paneer pizza",
  foodDetails:"Paneer pizza is traditional pizza recipe but the toppings is different it contains paneer",
  foodPrice  :" 230",
  foodImg:"../../assets/img/pizza.jpeg"
  


},

{   
  id:5,
  foodName:"Ice cream",
  foodDetails:"Ice cream is a sweetened frozen food typically eaten as a snack or dessert.",
  foodPrice  :" 90",
  foodImg:"../../assets/img/icecream.jpg"
  


},
{   
  id:6,
  foodName:"Paneer_sandwich",
  foodDetails:"Paneer sandwich is a quick, delicious and protein-packed  made with crumbled paneer",
  foodPrice  :" 100",
  foodImg:"../../assets/img/paneer_sandwich.jpg"
  


}




]










}
